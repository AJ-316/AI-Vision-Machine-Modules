
class Tab:

    def __init__(self):
