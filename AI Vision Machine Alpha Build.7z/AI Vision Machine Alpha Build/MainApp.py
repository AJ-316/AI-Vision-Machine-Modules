import customtkinter as ck
from GUI.CustomTabView import CustomTabView
from typing import Literal
import Configs


class SideFrame(ck.CTkFrame):
    SIDE = Literal['left', 'right']

    def __init__(self, main_frame, width, side: SIDE):
        super().__init__(main_frame, width=width, fg_color=Configs.FRAME_BG,
                         border_width=2, border_color=Configs.FRAME_BORDER_BG)
        self.pack_propagate(False)
        self.pack(ipadx=0, padx=Configs.SIDE_FRAME_PADDING, pady=Configs.SIDE_FRAME_PADDING, side=side, fill="y")

    def create_button(self, text, pady, command: callable(None) = None):
        button = ck.CTkButton(self, text=text, border_width=2, border_color=Configs.BTN_BORDER_BG,
                              font=Configs.FONTS["JetBrains Mono_16"], text_color=Configs.BUTTON_TEXT_BG,
                              fg_color=Configs.BTN_BG, hover_color=Configs.BTN_HOVER_BG)
        if command is not None:
            button.configure(command=lambda btn=button: command(btn))
        button.pack(pady=pady)
        return button


class MainFrame(ck.CTk):

    def __init__(self, title, geometry):
        super().__init__(fg_color=Configs.WIN_BG)
        self.title(title)
        self.geometry(geometry)
        Configs.load_configs()


class MainApp:
    def __init__(self):
        main = MainFrame("AI Vision Machine Modules Application v0.01",
                         f"{Configs.WIN_WIDTH}x{Configs.WIN_HEIGHT}")
        side_frame = SideFrame(main, Configs.SIDE_FRAME_WIDTH, "right")
        side_frame.create_button("Click11", pady=25)
        side_frame.create_button("Click22", pady=0)
        side_frame.create_button("Click33", pady=25)

        tabs = CustomTabView(main)
        tabs.pack(fill="both", expand=True, padx=24, pady=24)

        try:
            main.mainloop()
        except KeyboardInterrupt as e:
            print(f"Keyboard Interrupt{e}")


if __name__ == "__main__":
    MainApp()
